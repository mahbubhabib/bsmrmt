<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমান মেমোরিয়াল ট্রাস্ট</title>
    <!-- Bootstrap core CSS-->
    <link href="public/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="public/css/sb-admin.css" rel="stylesheet">
    <link href="public/css/style.css" rel="stylesheet">
</head>

<body class="bg-dark">

<div class="container">
    <div class="card card-login mx-auto mt-5">
        <div class="card-header">Login</div>
        <div class="card-body">
            <form method="post">
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input class="form-control" type="email" aria-describedby="emailHelp" placeholder="Enter email" name = "email" >
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input class="form-control" id="exampleInputPassword1" type="password" name = "password" placeholder="Enter Password" >
                </div>

                <input class="btn btn-primary btn-block" type = "submit" id="submit" name = "submit" value = "SignIn"></br>
            </form>
            <?php echo isset($msg)?$msg:"" ?>


        </div>
    </div>
</div>

<script src="public/js/jquery.min.js"></script>
<script src="public/js/bootstrap.min.js"></script>
<!--<script type="text/javascript">-->
<!--    $(document).ready(function () {-->
<!--        $('#submit').click(function () {-->
<!--            $('#error').show('fade');-->
<!--        });-->
<!--    });-->
<!--</script>-->

</body>

</html>