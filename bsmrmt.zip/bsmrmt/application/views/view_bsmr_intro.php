<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমান মেমোরিয়াল ট্রাস্ট</title>
    <!-- Bootstrap core CSS-->
    <link href="../public/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="../public/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Custom styles for this template-->
    <link href="../public/css/sb-admin.css" rel="stylesheet">
<!--    <script type="text/javascript" src="../public/ckeditor.js"></script>-->
<!--    <script type="text/javascript" src="../public/sample.js"></script>-->
    <script src="//cdn.ckeditor.com/4.8.0/full/ckeditor.js"></script>
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
<!-- Navigation-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="/bsmrmt/adminPanel">জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমান মেমোরিয়াল ট্রাস্ট</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
                <a class="nav-link" href="/bsmrmt/adminPanel">
                    <i class="fa fa-fw fa-table"></i>
                    <span class="nav-link-text">ড্যাশবোর্ড </span>
                </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" >
                <a class="nav-link" href="/bsmrmt/adminPanel/intro">
                    <i class="fa fa-fw fa-dashboard"></i>
                    <span class="nav-link-text">বঙ্গবন্ধু পরিচিতি</span>
                </a>
            </li>

            <li class="nav-item" data-toggle="tooltip" data-placement="right" >
                <a class="nav-link" href="/bsmrmt/adminPanel/trust_intro">
                    <i class="fa fa-fw fa-link"></i>
                    <span class="nav-link-text">ট্রাস্ট পরিচিতি</span>
                </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" >
                <a class="nav-link" href="/bsmrmt/adminPanel/trust_aim">
                    <i class="fa fa-fw fa-area-chart"></i>
                    <span class="nav-link-text">ট্রাস্টের  উদ্দেশ্য </span>
                </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" >
                <a class="nav-link" href="/bsmrmt/adminPanel/trust_work">
                    <i class="fa fa-fw fa-table"></i>
                    <span class="nav-link-text">ট্রাস্টের কার্যাবলি</span>
                </a>
            </li>

            <li class="nav-item" data-toggle="tooltip" data-placement="right">
                <a class="nav-link" href="/bsmrmt/adminPanel/photo">
                    <i class="fa fa-fw fa-link"></i>
                    <span class="nav-link-text">ফটো আর্কাইভ</span>
                </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" >
                <a class="nav-link" href="/bsmrmt/adminPanel/video">
                    <i class="fa fa-fw fa-area-chart"></i>
                    <span class="nav-link-text">ভিডিও আর্কাইভ</span>
                </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" >
                <a class="nav-link" href="/bsmrmt/adminPanel/bani">
                    <i class="fa fa-fw fa-table"></i>
                    <span class="nav-link-text">বানী</span>
                </a>
            </li>
        </ul>
        <ul class="navbar-nav sidenav-toggler">
            <li class="nav-item">
                <a class="nav-link text-center" id="sidenavToggler">
                    <i class="fa fa-fw fa-angle-left"></i>
                </a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link"   href="/bsmrmt/adminPanel/logout">
                    <i class="fa fa-fw fa-sign-out"></i>লগআউট</a>
            </li>
        </ul>
    </div>
</nav>
<div class="content-wrapper">
    <div class="container-fluid">
        <div class="alert alert-success alert-dismissable collapse" id="success">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <strong>Succesfully Insert content!!</strong>?>
        </div>
        <div class="card card-register mx-auto mt-5">
            <div class="card-header">বঙ্গবন্ধু পরিচিতি</div>
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                                <label for="exampleInputName">Title</label>
                                <input class="form-control" id="exampleInputName" name="title" type="text" aria-describedby="nameHelp" placeholder="Enter title here">
                        <td><?php echo form_error('title', '<p class="error">', '</p>'); ?></td>
                    </div>
                    <div class="form-group">
                        <label >Description</label>
                        <textarea class="form-control" id="body" name="body"  placeholder="Enter description here" rows="3"></textarea>
                        <td><?php echo form_error('body', '<p class="error">', '</p>'); ?></td>
                    </div>
                    <input class="btn btn-primary btn-block" type="submit" name="submit" id="submit" value="Save">
                </form>
            </div>

    </div>

</div>
<!-- /.container-fluid-->
<!-- /.content-wrapper-->
<footer class="sticky-footer">
    <div class="container">
        <div class="text-center">
            <small>Copyright © জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমান মেমোরিয়াল ট্রাস্ট 2017</small>
        </div>
    </div>
</footer>
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fa fa-angle-up"></i>
</a>

<!-- Bootstrap core JavaScript-->
    <script src="../public/js/jquery.min.js"></script>
    <script src="../public/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#submit').click(function () {
                $('#success').show('fade');
            });
        });
    </script>

<script src="../public/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="../public/js/jquery.easing.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="../public/js/sb-admin.min.js"></script>
<!--    <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>-->
<!--    <script>tinymce.init({ selector:'textarea' });</script>-->
    <script type="text/javascript">
        CKEDITOR.replace( 'body' );
    </script>
</div>
</body>

</html>
