<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমান মেমোরিয়াল ট্রাস্ট</title>
  <!-- Bootstrap core CSS-->
  <link href="public/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="public/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="public/css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="/bsmrmt/adminPanel">জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমান মেমোরিয়াল ট্রাস্ট</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
              <a class="nav-link" href="/bsmrmt/adminPanel">
                  <i class="fa fa-fw fa-table"></i>
                  <span class="nav-link-text">ড্যাশবোর্ড </span>
              </a>
          </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" >
          <a class="nav-link" href="/bsmrmt/adminPanel/intro">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">বঙ্গবন্ধু পরিচিতি</span>
          </a>
        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" >
          <a class="nav-link" href="/bsmrmt/adminPanel/trust_intro">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">ট্রাস্ট পরিচিতি</span>
          </a>
        </li>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" >
              <a class="nav-link" href="/bsmrmt/adminPanel/trust_aim">
                  <i class="fa fa-fw fa-area-chart"></i>
                  <span class="nav-link-text">ট্রাস্টের  উদ্দেশ্য </span>
              </a>
          </li>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" >
              <a class="nav-link" href="/bsmrmt/adminPanel/trust_work">
                  <i class="fa fa-fw fa-table"></i>
                  <span class="nav-link-text">ট্রাস্টের কার্যাবলি</span>
              </a>
          </li>

          <li class="nav-item" data-toggle="tooltip" data-placement="right">
              <a class="nav-link" href="/bsmrmt/adminPanel/photo">
                  <i class="fa fa-fw fa-link"></i>
                  <span class="nav-link-text">ফটো আর্কাইভ</span>
              </a>
          </li>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" >
              <a class="nav-link" href="/bsmrmt/adminPanel/video">
                  <i class="fa fa-fw fa-area-chart"></i>
                  <span class="nav-link-text">ভিডিও আর্কাইভ</span>
              </a>
          </li>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" >
              <a class="nav-link" href="/bsmrmt/adminPanel/bani">
                  <i class="fa fa-fw fa-table"></i>
                  <span class="nav-link-text">বানী</span>
              </a>
          </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i>লগআউট</a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-xl-3 col-sm-6 mb-3">
                <div class="card text-white bg-primary o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fa-fw fa-comments"></i>
                        </div>
                        <div class="mr-5">বঙ্গবন্ধু পরিচিতি</div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="/bsmrmt/adminPanel/bsmr_intro_show">
                        <span class="float-left">বিস্তারিত</span>
                        <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
                    </a>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
                <div class="card text-white bg-warning o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fa-fw fa-list"></i>
                        </div>
                        <div class="mr-5">ট্রাস্ট পরিচিতি</div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="/bsmrmt/adminPanel/trust_intro_show">
                        <span class="float-left">বিস্তারিত</span>
                        <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
                    </a>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
                <div class="card text-white bg-success o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fa-fw fa-shopping-cart"></i>
                        </div>
                        <div class="mr-5">ট্রাস্টের  উদ্দেশ্য </div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="/bsmrmt/adminPanel/trust_aim_show">
                        <span class="float-left">বিস্তারিত</span>
                        <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
                    </a>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
                <div class="card text-white bg-danger o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fa-fw fa-support"></i>
                        </div>
                        <div class="mr-5">ট্রাস্টের কার্যাবলি</div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="/bsmrmt/adminPanel/trust_work_show">
                        <span class="float-left">বিস্তারিত</span>
                        <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
                    </a>
                </div>
            </div>

            <div class="col-xl-3 col-sm-6 mb-3">
                <div class="card text-white bg-success o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fa-fw fa-shopping-cart"></i>
                        </div>
                        <div class="mr-5">ফটো আর্কাইভ</div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="/bsmrmt/adminPanel/photo_show">
                        <span class="float-left">বিস্তারিত</span>
                        <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
                    </a>
                </div>
            </div>

                <div class="col-xl-3 col-sm-6 mb-3">
                    <div class="card text-white bg-primary o-hidden h-100">
                        <div class="card-body">
                            <div class="card-body-icon">
                                <i class="fa fa-fw fa-comments"></i>
                            </div>
                            <div class="mr-5">ভিডিও আর্কাইভ</div>
                        </div>
                        <a class="card-footer text-white clearfix small z-1" href="/bsmrmt/adminPanel/video_show">
                            <span class="float-left">বিস্তারিত</span>
                            <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
                        </a>
                    </div>
                </div>

            <div class="col-xl-3 col-sm-6 mb-3">
                <div class="card text-white bg-danger o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fa-fw fa-support"></i>
                        </div>
                        <div class="mr-5">বানী</div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="/bsmrmt/adminPanel/bani_show">
                        <span class="float-left">বিস্তারিত</span>
                        <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
                    </a>
                </div>
            </div>


        </div>
    </div>

    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমান মেমোরিয়াল ট্রাস্ট 2017</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="/bsmrmt/adminPanel/logout">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="public/js/jquery.min.js"></script>
    <script src="public/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="public/js/jquery.easing.min.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="public/js/sb-admin.min.js"></script>
  </div>
</body>

</html>
