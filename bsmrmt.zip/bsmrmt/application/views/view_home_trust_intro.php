<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমান মেমোরিয়াল ট্রাস্ট</title>
    <link href="../public/css/bootstrap.css" rel="stylesheet">
    <link href="../public/css/font-awesome.css" rel="stylesheet">
    <link href="../public/css/style.css" rel="stylesheet">
    <link href="../public/css/owl.carousel.css" rel="stylesheet">
    <link href="../public/css/color.css" rel="stylesheet">
    <link href="../public/css/dl-menu.css" rel="stylesheet">
    <link href="../public/css/flexslider.css" rel="stylesheet">
    <link href="../public/css/prettyphoto.css" rel="stylesheet">
    <link href="../public/css/responsive.css" rel="stylesheet">
    <link rel="alternate stylesheet" type="text/css" href="switcher/color-one.css" title="color-one" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/color-two.css" title="color-two" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/color-three.css" title="color-three" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/color-four.css" title="color-four" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/color-five.css" title="color-five" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/color-six.css" title="color-six" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/color-seven.css" title="color-seven" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/color-eight.css" title="color-eight" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/color-nine.css" title="color-nine" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/color-ten.css" title="color-ten" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/color-ten.css" title="color-ten" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/pattren1.css" title="pattren1" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/pattren2.css" title="pattren2" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/pattren3.css" title="pattren3" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/pattren4.css" title="pattren4" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/pattren5.css" title="pattren5" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/background1.css" title="background1" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/background2.css" title="background2" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/background3.css" title="background3" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/background4.css" title="background4" media="screen" />
    <link rel="alternate stylesheet" type="text/css" href="switcher/background5.css" title="background5" media="screen" />
    <!--[if lt IE 9]> <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js">
    </script> <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js">
    </script> <![endif]-->
</head>
<body>
<div class="ec-main-wrapper">
    <header id="ec-header" class="ec-absolute">
        <div class="ec-social-strip">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <nav class="top-nav">
                            <!-- <ul>
                                <li><a href="#">সেবাসমূহ </a></li>
                                <li><a href="#">অনলাইন কার্যক্রম</a></li>
                                <li><a href="#">যোগাযোগ</a></li>
                            </ul>  -->
                        </nav>
                    </div>

                    <div class="col-md-6">
                        <div class="social-media">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a data-original-title="Twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a data-original-title="Google-Plus" href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a data-original-title="Dribbble" href="#"><i class="fa fa-dribbble"></i></a></li>
                                <li><a data-original-title="Pinterest" href="#"><i class="fa fa-pinterest-p"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="ec-topbar">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <a href="/bsmrmt" class="ec-logo"><img style="height: 110px;" src="../public/images/logo.png" alt=""></a>
                    </div>
                    <div class="col-md-6">
                        <ul class="ec-stripinfo">
                            <li> <i class="ec-color fa fa-phone"></i> <div class="strip-info-text"> <span>ফোন নংঃ </span> +৮৮০  ২  ৯১৩৩৯৯১ </div> </li>
                            <li> <i class="ec-color fa fa-map-marker"></i> <div class="strip-info-text"> <span>অবস্থান</span> ক্লিক করুন </div> </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="ec-mainheader">
                <div class="ec-left-section">
                    <nav class="main-navigation">
                        <ul>
                            <li class="active"><a href="/bsmrmt"><i class="fa fa-home"></i></a></li>
                            <li><a href="/bsmrmt/home/bsmr_intro">বঙ্গবন্ধু পরিচিতি </a></li>
                            <li><a href="#">ট্রাস্ট</a>
                                <ul class="as-dropdown">
                                    <li><a href="/bsmrmt/home/trust_intro">ট্রাস্ট পরিচিতি </a></li>
                                    <li><a href="/bsmrmt/home/trust_aim">ট্রাস্টের  উদ্দেশ্য</a></li>
                                    <li><a href="/bsmrmt/home/trust_work">ট্রাস্টের কার্যাবলি</a></li>
                                    <!-- <li><a href="portfolio-simple-side.php">ট্রাস্টের গঠনতন্ত্র</a></li>  -->
                                </ul>
                            </li>
                            <!-- <li><a href="#">কার্যক্রম</a></li> -->
                            <li><a href="#">আর্কাইভ</a>
                                <ul class="as-dropdown">
                                    <li><a href="/bsmrmt/home/photo">ফটো</a></li>
                                    <li><a href="/bsmrmt/home/video">ভিডিও</a></li>
                                    <li><a href="/bsmrmt/home/bani">বানী</a></li>
                                </ul>
                            </li>
                            <!-- <li><a href="#">ব্লগ</a></li>
                             <li><a href="#">মেম্বার</a>
                                <ul class="as-dropdown">
                                    <li><a href="team-grid.php">বোর্ড মেম্বার</a></li>
                                    <li><a href="team-medium.php">পরিচালনা পর্ষদ</a></li>
                                </ul>
                            </li> -->
                            <li><a href="/bsmrmt/home/update">আপডেট </a></li>
                            <li><a href="/bsmrmt/home/contact">যোগাযোগ</a></li>
                        </ul>
                    </nav>

                    <!-- <div id="as-menu" class="as-menuwrapper">
                        <button class="as-trigger">Open Menu</button>
                            <ul class="as-menu">
                                <li class="active"><a href="index.php">Home</a></li>
                                <li><a href="about-us.php">about</a></li>
                                <li><a href="services.php">services</a></li>
                                <li><a href="#">Blog</a>
                                    <ul class="as-submenu">
                                        <li><a href="blog-grid.php">blog Grid</a></li>
                                        <li><a href="blog-large.php">blog Large</a></li>
                                        <li><a href="blog-medium.php">blog Medium</a></li>
                                        <li><a href="blog-detail.php">blog detail</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">portfolio</a>
                                    <ul class="as-submenu">
                                        <li><a href="portfolio-grid.php">portfolio Modren</a></li>
                                        <li><a href="portfolio-grid-2column.php">Modren 2column</a></li>
                                        <li><a href="portfolio-grid-3column.php">Modren 3column</a></li>
                                        <li><a href="portfolio-simple.php">Portfolio Simple</a></li>
                                        <li><a href="portfolio-simple-side.php">Portfolio with sidebar</a></li>
                                        <li><a href="portfolio-detail.php">Portfolio Detail</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Team</a>
                                    <ul class="as-submenu">
                                        <li><a href="team-grid.php">team Grid</a></li>
                                        <li><a href="team-medium.php">team medium</a></li>
                                        <li><a href="team-detail.php">team detail</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Shop</a>
                                    <ul class="as-submenu">
                                        <li><a href="shop-list.php">Shop List</a></li>
                                        <li><a href="shop-detail.php">shop detail</a></li>
                                    </ul>
                                </li>
                                <li><a href="shortcode.php">shortcode</a></li>
                                <li><a href="#">Pages</a>
                                    <ul class="as-submenu">
                                        <li><a href="404.php">404 Page</a></li>
                                        <li><a href="underconstruction.php">UnderConstruction</a></li>
                                    </ul>
                                </li>
                                <li><a href="contact-us.php">contact us</a></li>
                            </ul>
                    </div>  -->
                </div>
                <a href="http://bsmrmt.appsbean.com/" class="ec-getqoute ec-bgcolor" ><i class="fa fa-edit"></i>পূর্ণমিলনী আবেদন</a>
                <!--<a href="http://bsmrmt.appsbean.com/" class="ec-getqoute ec-bgcolor" data-toggle="modal" data-target="#myModal"><i class="fa fa-edit"></i>আবেদন</a>-->
            </div>
        </div>
    </header>
    <div class="ec-minheader">
        <div class="ec-minheader-wrap">
            <span class="full-pattren"></span>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ec-page-title"> <h1>ট্রাস্ট পরিচিতি </h1> <p></p> </div>
                    </div>
                    <div class="col-md-12"> <ul class="ec-breadcrumb"> <li><a href="#">হোম পেজ </a></li> <li class="active"><a href="#">ট্রাস্ট পরিচিতি </a></li> </ul> </div>
                </div>
            </div>
        </div>
    </div>

    <div class="ec-main-content">
        <div class="ec-main-section ec-main-cninfo">
            <div class="container">
                <?php foreach($bsmr as $intro){?>
                    <?php echo $intro->body ;?>
                <?php } ?>
            </div>
        </div>
    </div>



    <!--/ Footer /-->
    <footer id="ec-footer">
        <!--/ Footer Widget /-->
        <div class="ec-footer-widget">
            <div class="container">
                <div class="row">
                    <aside class="widget col-md-3 widget_info">
                        <div class="ec-main-title"> <h2>যোগাযোগ</h2> </div>
                        <ul>
                            <li><i class="fa fa-bank"></i> বঙ্গবন্ধু ভবন, বাড়ি-০৮, সড়ক-৩২, ধানমন্ডি আ/এ, ঢাকা-১২০৯</li>
                            <li><i class="fa fa-phone"></i> ফোন নং +৮৮০ ২ ৯১৩৩৯৯১</li>
                            <li><i class="fa fa-envelope-o" aria-hidden="true"></i> info@bsmrmt.com</li>
                            <li><i class="fa fa-globe" aria-hidden="true"></i> <a href="#">www.bsmrmt.com</a></li>
                        </ul>
                    </aside>
                    <aside class="widget col-md-3 widget_categories">
                        <div class="ec-main-title"> <h2>সাম্প্রতিক পোস্ট </h2> </div>
                        <ul>
                            <li><a href="#">ব্লগ </a> (১২)</li>
                            <li><a href="#">নোটিস</a> (১২ )</li>
                            <li><a href="#">খবর </a> (১২ )</li>
                            <li><a href="#">বিজ্ঞপ্তি </a> (১২)</li>
                        </ul>
                    </aside>
                    <aside class="widget col-md-3 widget_gallery">
                        <div class="ec-main-title"> <h2>আমাদের ছবি </h2> </div>
                        <ul class="gallery">
                            <li><a href="../public/extra-images/gallery-widget-1-copy.jpg" data-rel="prettyPhoto[gallery1]" title=""><img src="../public/extra-images/gallery-widget-1.jpg" alt=""></a></li>

                            <li><a href="../public/extra-images/gallery-widget-2-copy.jpg" data-rel="prettyPhoto[gallery1]" title=""><img src="../public/extra-images/gallery-widget-2.jpg" alt=""></a></li>

                            <li><a href="../public/extra-images/gallery-widget-3-copy.jpg" data-rel="prettyPhoto[gallery1]" title=""><img src="../public/extra-images/gallery-widget-3.jpg" alt=""></a></li>

                            <li><a href="../public/extra-images/gallery-widget-4-copy.jpg" data-rel="prettyPhoto[gallery1]" title=""><img src="../public/extra-images/gallery-widget-4.jpg" alt=""></a></li>

                            <li><a href="../public/extra-images/gallery-widget-5-copy.jpg" data-rel="prettyPhoto[gallery1]" title=""><img src="../public/extra-images/gallery-widget-5.jpg" alt=""></a></li>

                            <li><a href="../public/extra-images/gallery-widget-6-copy.jpg" data-rel="prettyPhoto[gallery1]" title=""><img src="../public/extra-images/gallery-widget-6.jpg" alt=""></a></li>
                        </ul>
                    </aside>
                    <aside class="widget col-md-3 widget_form">
                        <div class="ec-main-title"> <h2>জরুরী যোগাযোগ </h2> </div>
                        <form>
                            <ul>
                                <li><input type="text" placeholder="নাম" required></li>
                                <li><input type="text" placeholder="ইমেল" required></li>
                                <li><textarea placeholder="বার্তা" required></textarea></li>
                                <li><input type="submit" class="ec-bgcolor" value="প্রেরণ"></li>
                            </ul>
                        </form>
                    </aside>
                </div>
            </div>
        </div>
        <!--/ Footer Widget /-->

        <div class="ec-bottom-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="ec-copyright">
                            <p>২০১৭ সকল তথ্য বঙ্গবন্ধু মেমোরিয়াল ট্রাস্ট কর্তিক সংরক্ষিত <br />Developed By: <a href="http://www.wepeoplebd.com/" class="ec-colorhover">We People Ltd.</a></p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="ec-social-network">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook"></i> <span>Facebook</span></a></li>
                                <li><a href="#" data-original-title="Twitter"><i class="fa fa-twitter"></i> <span>Twitter</span></a></li>
                                <li><a href="#" data-original-title="Google-Plus"><i class="fa fa-google-plus"></i> <span>Google-Plus</span></a></li>
                                <li><a href="#" data-original-title="Dribbble"><i class="fa fa-dribbble"></i> <span>Dribbble</span></a></li>
                                <li><a href="#" data-original-title="Pinterest"><i class="fa fa-pinterest-p"></i> <span>Pinterest</span></a></li>
                            </ul>
                        </div>
                        <a class="backtop-btn" href="#"><i class="fa fa-angle-double-up as-color"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--/ Footer /-->


    <div class="clearfix"></div>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content ec-userlogin">
            <div class="modal-header ec-bgcolor">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
                <h5>GET A QUOTE</h5>
            </div>
            <div class="modal-body">
                <form>
                    <ul class="ec-login-form">
                        <li> <label>Name</label> <input type="text" placeholder="Name" required> </li>
                        <li class="half-grid no-padding"> <label>Email</label> <input type="password" placeholder="Email" required> </li>
                        <li class="half-grid"> <label>Mobile Number</label> <input type="text" placeholder="Mobile Number" required> </li>
                        <li class="half-grid no-padding"> <label>Service Type</label> <input type="text" placeholder="Service Type" required> </li>
                        <li class="half-grid">
                            <label>Number of Workers</label>
                            <div class="select-parent">
                                <select> <option>1</option> <option>2</option> <option>3</option> <option>4</option> <option>5</option> </select>
                            </div>
                        </li>
                        <li class="half-grid no-padding">
                            <label>Date</label>
                            <div id="datetimepicker2" class="input-append">
                                <input data-format="MM/dd/yyyy HH:mm:ss PP" type="text"> <span class="input-group-addon add-on"><span class="fa fa-calendar"></span></span>
                            </div>
                        </li>
                        <li class="half-grid"> <label>Time</label> <div id="datetimepicker3" class="input-append"> <input data-format="hh:mm:ss" type="text"> <span class="input-group-addon add-on"><span class="fa fa-clock-o"></span></span> </div> </li>
                        <li> <label>Address</label> <input type="text" placeholder="Address" required> </li>
                        <li> <label>Message</label> <textarea></textarea> </li>
                        <li> <input type="submit" value="GET A QUOTE" class="ec-bgcolor"> </li>
                    </ul>
                </form>
            </div>
        </div>
    </div>
</div>
<!--Java Script-->
<script src="../public/script/jquery.min.js"></script>
<script src="../public/script/modernizr.js"></script>
<script src="../public/script/bootstrap.min.js"></script>
<script src="../public/script/jquery.dlmenu.js"></script>
<script src="../public/script/flexslider-min.js"></script>
<script src="../public/script/jquery.countdown.min.js"></script>
<script src="../public/script/jquery.prettyphoto.js"></script>
<script src="../public/script/waypoints-min.js"></script>
<script src="../public/script/owl.carousel.min.js"></script>
<script src="../public/script/custom.js"></script>
<script src="../public/script/isotope.min.js"></script>
<script src="../public/script/fitvideo.js"></script>
<script src="../public/script/bootstrap-datetimepicker.min.js"></script>
<script src="../public/script/styleswitch.js"></script>
<script src="../public/script/functions.js"></script>
<!--Java Script-->
</body>
</html>