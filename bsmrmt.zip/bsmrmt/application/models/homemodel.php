<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: MahbubHabib
 * Date: 14-01-18
 * Time: 19.25
 */
class Homemodel extends CI_Model
{
    public function addTrustAimShow()
    {
        $this->db->select("*");
        $this->db->from('trust_aim');
        $this->db->order_by('id','DESC');
        $this->db->limit(1);
        $result = $this->db->get();

        return $result->result();
    }

    public function addPhotoShow()
    {
        $this->db->select("*");
        $this->db->from("photo");
        $this->db->order_by('id','DESC');
        $this->db->limit(12);
        $result = $this->db->get();

        return $result->result();
    }

    public function addTrustWorkShow()
    {
        $this->db->select("*");
        $this->db->from("trust_work");
        $this->db->limit(4);
        $result = $this->db->get();
//        $sql ="SELECT id,title,LEFT('body',5) FROM trust_work LIMIT 0,4";
//        $result= $this->db->query($sql);

        return $result->result();
    }
//-------------------------------------------------------
    public function trustWorkDetails($id)
    {
//        $this->db->select("*");
//        $this->db->from("trust_work");
        $this->db->where('id',$id);
        $result = $this->db->get('trust_work');

        return $result->result();
    }

    public function addBsmrmtIntroShow()
    {
        $this->db->select("*");
        $this->db->from("bsmr_intro");
        $this->db->order_by('id','DESC');
        $this->db->limit(1);
        $result = $this->db->get();

        return $result->result();
    }

    public function addHomeTrustIntroShow()
    {
        $this->db->select("*");
        $this->db->from("trust_intro");
        $this->db->order_by('id','DESC');
        $this->db->limit(1);
        $result = $this->db->get();

        return $result->result();
    }

    public function addVideoShow()
    {
        $this->db->select("*");
        $this->db->from("video");
        $result = $this->db->get();

        return $result->result();
    }

    public function addbaniShow()
    {
        $this->db->select("*");
        $this->db->from("bani");
        $result = $this->db->get();

        return $result->result();
    }
}