<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: MahbubHabib
 * Date: 13-01-18
 * Time: 00.39
 */
class Adminmodel extends CI_Model
{
    public function addIntro($title, $body)
    {

        $sql = "INSERT INTO bsmr_intro VALUES (null, '$title','$body')";
        $this->db->query($sql);
    }

    public function addTrustIntro($title, $body)
    {

        $sql = "INSERT INTO trust_intro VALUES (null, '$title','$body')";
        $this->db->query($sql);
    }

    public function addAim($title, $body)
    {

        $sql = "INSERT INTO trust_aim VALUES (null, '$title','$body')";
        $this->db->query($sql);
    }

    public function addWork($title,$short, $body)
    {

        $sql = "INSERT INTO trust_work VALUES (null, '$title','$short','$body')";
        $this->db->query($sql);
    }
    //;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;''''''''''''''''''''''''''''''''''''''''''';;;;;;;;;;;;;;;;;;;;;;;;;
    public function addFolder($title)
    {

        $sql = "INSERT INTO folder VALUES (null, '$title')";
        $this->db->query($sql);
    }
    public function getFolder()
    {

        $this->db->select("*");
        $this->db->from('folder');

        $query = $this->db->get();
        return $query->result();
    }
//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;''''''''''''''''''''''''''''''''''''''''''';;;;;;;;;;;;;;;;;;;;;;;;;
    public function addBani($title, $body)
    {

        $sql = "INSERT INTO bani VALUES (null, '$title','$body')";
        $this->db->query($sql);
    }

    public function addPhoto($title, $photo,$folder)
    {

        $sql = "INSERT INTO photo VALUES (null, '$title','$photo','$folder')";
        $this->db->query($sql);
    }

    public function addVideo($title, $video)
    {

        $sql = "INSERT INTO video VALUES (null, '$title','$video')";
        $this->db->query($sql);
    }

    public function addBsmrIntroShow()
    {
        $this->db->select("*");
        $result = $this->db->get("bsmr_intro");

        return $result->result();
    }

    public function addBsmrIntroDelete($id)
    {
        $this->db->where("id", $id);
        $this->db->delete("bsmr_intro");
    }

    public function addTrustIntroShow()
    {
        $this->db->select("*");
        $result = $this->db->get("trust_intro");

        return $result->result();
    }

    public function addTrustIntroDelete($id)
    {
        $this->db->where("id", $id);
        $this->db->delete("trust_intro");
    }

    public function addTrustAimShow()
    {
        $this->db->select("*");
        $result = $this->db->get("trust_aim");

        return $result->result();
    }

    public function addTrustAimDelete($id)
    {
        $this->db->where("id", $id);
        $this->db->delete("trust_aim");
    }

    public function addTrustWorkShow()
    {
        $this->db->select("*");
        $result = $this->db->get("trust_work");

        return $result->result();
    }

    public function addTrustWorkDelete($id)
    {
        $this->db->where("id", $id);
        $this->db->delete("trust_work");
    }

    public function addPhotoShow()
    {
        $this->db->select("*");
        $result = $this->db->get("photo");

        return $result->result();
    }

    public function addPhotoDelete($id)
    {
        $this->db->where("id", $id);
        $this->db->delete("photo");
    }

    public function addVideoShow()
    {
        $this->db->select("*");
        $result = $this->db->get("video");

        return $result->result();
    }

    public function addVideoDelete($id)
    {
        $this->db->where("id", $id);
        $this->db->delete("video");
    }

    public function addBaniShow()
    {
        $this->db->select("*");
        $result = $this->db->get("bani");

        return $result->result();
    }

    public function addBaniDelete($id)
    {
        $this->db->where("id", $id);
        $this->db->delete("bani");
    }

    public function getBsmrIntro($id){
        $this->db->select("*");
        $this->db->where("id",$id);
        $result = $this->db->get("bsmr_intro");

        return $result->row_array();
    }

    public function updateBsmrIntro($id,$title,$body){
        $sql = "UPDATE bsmr_intro SET title='$title',body='$body' WHERE id='$id'";

        $this->db->query($sql);
    }

    public function getTrustIntro($id){
        $this->db->select("*");
        $this->db->where("id",$id);
        $result = $this->db->get("trust_intro");

        return $result->row_array();
    }

    public function updateTrustIntro($id,$title,$body){
        $sql = "UPDATE trust_intro SET title='$title',body='$body' WHERE id='$id'";

        $this->db->query($sql);
    }
}