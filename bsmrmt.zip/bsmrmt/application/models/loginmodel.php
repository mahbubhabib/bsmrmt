<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


/**
 * Created by PhpStorm.
 * User: MahbubHabib
 * Date: 12-01-18
 * Time: 23.31
 */
class Loginmodel extends CI_Model
{
    //---------------Admin login----------------
    public function verifyAdmin($email,$password)
    {
        $this->db->where("email",$email);
        $this->db->where("password",$password);
        $this->db->where("type","admin");
        $result = $this->db->get("users");

        $row = $result->row_array();

        if($row)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}