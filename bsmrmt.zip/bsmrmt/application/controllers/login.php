<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('form','url','file');
        $this->load->library('form_validation');
        $this->load->model('loginmodel');
    }
	public function index()
	{

        if ($this->input->post('submit')) {
            $emaill = $this->input->post('email');
            $password = $this->input->post('password');

            if ($this->loginmodel->verifyAdmin($emaill, $password)) {

                $this->session->set_userdata('admin', $emaill);

                $this->load->helper('url');
                redirect("http://localhost/bsmrmt/adminPanel","refresh");

            }else
            {
                $data['msg'] = "Invalid Email or password";
                $this->parser->parse('view_login', $data);
            }


        }else {
            $this->load->view('view_login');
        }
	}
}