<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: MahbubHabib
 * Date: 13-01-18
 * Time: 00.38
 */
class AdminPanel extends CI_Controller
{
    //variable for storing error message
    private $error;
    //variable for storing success message
    private $success;

    public function __construct()
    {
        parent::__construct();
        if(! $this->session->userdata('admin'))
        {
            $this->load->helper('url');
            redirect('http://localhost/bsmrmt/login', 'refresh');
            return;
        }
        $this->load->helper('form', 'url', 'file');
        $this->load->library('form_validation');
        $this->load->model('adminmodel');
    }

    //appends all error messages
    private function handle_error($err) {
        $this->error .= $err . "rn";
    }

    //appends all success messages
    private function handle_success($succ) {
        $this->success .= $succ . "rn";
    }

    public function index()
    {
        $this->load->view('view_admindashboard');
    }

 //   --------------------------BSMR INTRO---------------------------
    public function intro()
    {
        $this->form_validation->set_rules("title", "title", "required");
        $this->form_validation->set_rules("body", "body", "required");


        if ($this->form_validation->run() == false) {

            $this->load->view('view_bsmr_intro');
        } else {

            if ($this->input->post('submit')) {
                $title = $this->input->post("title");
                $body = $this->input->post("body");

                $this->adminmodel->addIntro($title, $body);
                $this->load->view('view_bsmr_intro');

            }
        }
    }

    //---------------------------Trust Intro--------------------------
    public function trust_intro()
    {
        $this->form_validation->set_rules("title", "title", "required");
        $this->form_validation->set_rules("body", "body", "required");


        if ($this->form_validation->run() == false) {

            $this->load->view('view_trust_intro');
        } else {

            if ($this->input->post('submit')) {
                $title = $this->input->post("title");
                $body = $this->input->post("body");

                $this->adminmodel->addTrustIntro($title, $body);
                $this->load->view('view_trust_intro');

            }
        }
    }


    //---------------------------Trust Aim--------------------------
    public function trust_aim()
    {
        $this->form_validation->set_rules("title", "title", "required");
        $this->form_validation->set_rules("body", "body", "required");


        if ($this->form_validation->run() == false) {

            $this->load->view('view_trust_aim');
        } else {

            if ($this->input->post('submit')) {
                $title = $this->input->post("title");
                $body = $this->input->post("body");

                $this->adminmodel->addAim($title, $body);
                $this->load->view('view_trust_aim');

            }
        }
    }


    //---------------------------Trust Work--------------------------
    public function trust_work()
    {
        $this->form_validation->set_rules("title", "title", "required");
        $this->form_validation->set_rules("short", "short descrition", "required");
        $this->form_validation->set_rules("body", "body", "required");


        if ($this->form_validation->run() == false) {

            $this->load->view('view_trust_work');
        } else {

            if ($this->input->post('submit')) {
                $title = $this->input->post("title");
                $short = $this->input->post("short");
                $body = $this->input->post("body");

                $this->adminmodel->addWork($title,$short, $body);
                $this->load->view('view_trust_work');

            }
        }
    }

    //---------------------------Photo--------------------------
    public function photo()
    {
        $this->form_validation->set_rules("title", "title", "required");

        $config_image = array();
        $config_image['upload_path'] = './pic/'.$this->input->post('folder');
        $config_image['allowed_types'] = 'jpg|png|gif';
        $config_image['max_size'] = '1024';

        $this->load->library('upload',$config_image);
        $this->upload->initialize($config_image);

        if ($this->form_validation->run() == false) {
            $name['name']= $this->adminmodel->getFolder();
            $this->load->view('view_photo',$name);
        } elseif ($this->form_validation->run() == true and !empty($_FILES['picturefile']['name'][0])){

            $temp=$this->upload->do_upload('picturefile');
            //var_dump($temp);

            $data = array('upload_data' =>$this->upload->data());

            $this->image_resize($data['upload_data']['full_path'],$data['upload_data']['file_name']);

            $title = $this->input->post("title");
            $folder = $this->input->post("folder");
            $photo = $data['upload_data']['file_name'];

            $this->adminmodel->addPhoto($title, $photo,$folder);
            $msg="success";
            $this->load->view('view_photo',$msg);

        }
    }

    public function image_resize($path,$file)
    {
        $config_resize = array();
        $config_resize['image_library'] = 'gd2';
        $config_resize['source_image'] = $path;
        $config_resize['maintain_ratio'] =TRUE;
        $config_resize['width'] = 75;
        $config_resize['height'] = 50;
        $config_resize['new_image'] = './pic/thumb/'.$file;
        $this->load->library('image_lib',$config_resize);
        $this->image_lib->resize();
    }
//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;''''''''''''''''''''''''''''''''''''''''''';;;;;;;;;;;;;;;;;;;;;;;;;
    public function create_folder()
    {
        $this->form_validation->set_rules("title", "title", "required");

        $path = "./pic/". $this->input->post('title');

        if(!is_dir($path)) //create the folder if it's not already exists
        {
            mkdir($path,0777,TRUE);
        }


        if ($this->form_validation->run() == false) {

            $this->load->view('view_create_folder');
        } else {

            if ($this->input->post('submit')) {
                $title = $this->input->post("title");


                $this->adminmodel->addFolder($title);
                $this->load->view('view_create_folder');

            }
        }
    }
//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;''''''''''''''''''''''''''''''''''''''''''';;;;;;;;;;;;;;;;;;;;;;;;;

    //---------------------------Video--------------------------
//    public function video(){
//
//        if ($this->input->post('video_upload')) {
//            //set preferences
//            //file upload destination
//            $upload_path = './upload/';
//            $config['upload_path'] = $upload_path;
//            //allowed file types. * means all types
//            $config['allowed_types'] = 'wmv|mp4|avi|mov';
//            //allowed max file size. 0 means unlimited file size
//            $config['max_size'] = '0';
//            //max file name size
//            $config['max_filename'] = '255';
//            //whether file name should be encrypted or not
//            $config['encrypt_name'] = FALSE;
//            //store video info once uploaded
//            $video_data = array();
//            //check for errors
//            $is_file_error = FALSE;
//            //check if file was selected for upload
//            if (!$_FILES) {
//                $is_file_error = TRUE;
//                $this->handle_error('Select a video file.');
//            }
//            //if file was selected then proceed to upload
//            if (!$is_file_error) {
//                //load the preferences
//                $this->load->library('upload', $config);
//                $this->upload->initialize($config);
//                //check file successfully uploaded. 'video_name' is the name of the input
//                if (!$this->upload->do_upload('video_name')) {
//                    //if file upload failed then catch the errors
//                    $this->handle_error($this->upload->display_errors());
//                    $is_file_error = TRUE;
//                } else {
//                    //store the video file info
//                    $video_data = $this->upload->data();
//                }
//            }
//            // There were errors, we have to delete the uploaded video
//            if ($is_file_error) {
//                if ($video_data) {
//                    $file = $upload_path . $video_data['file_name'];
//                    if (file_exists($file)) {
//                        unlink($file);
//                    }
//                }
//            } else {
//                $data['video_name'] = $video_data['file_name'];
//                $data['video_path'] = $upload_path;
//                $data['video_type'] = $video_data['file_type'];
//                $title = $this->input->post("title");
//                $video = $data['video_name'];
//
//                $this->adminmodel->addVideo($title, $video);
//                $this->handle_success('Video was successfully uploaded to direcoty');
//            }
//        }
//        //load the error and success messages
//        $data['errors'] = $this->error;
//        $data['success'] = $this->success;
//        //load the view along with data
//        $this->load->view('view_video', $data);
//
//    }


    public function video(){
        $this->form_validation->set_rules("title", "title", "required");
        $this->form_validation->set_rules("link", "video link", "required");


        if ($this->form_validation->run() == false) {

            $this->load->view('view_video');
        } else {

            if ($this->input->post('video_upload')) {
                $title = $this->input->post("title");
                $link = $this->input->post("link");

                $this->adminmodel->addVideo($title,$link);
                $this->load->view('view_video');

            }
        }
    }

    //---------------------------bani--------------------------
    public function bani()
    {
        $this->form_validation->set_rules("title", "title", "required");
        $this->form_validation->set_rules("body", "body", "required");


        if ($this->form_validation->run() == false) {

            $this->load->view('view_bani');
        } else {

            if ($this->input->post('submit')) {
                $title = $this->input->post("title");
                $body = $this->input->post("body");

                $this->adminmodel->addBani($title, $body);
                $this->load->view('view_bani');

            }
        }
    }
//--------------------Bsmrmt Edit-------------------
    public function bsmr_intro_edit($id)
    {


        $this->form_validation->set_rules("title", "title", "required");
        $this->form_validation->set_rules("body", "body", "required");


        if ($this->form_validation->run() == false) {

            $data['editPage']=$this->adminmodel->getBsmrIntro($id);
            $this->load->view('view_bsmr_intro_edit',$data);
        } else {

            if ($this->input->post('submit')) {
                $title = $this->input->post("title");
                $body = $this->input->post("body");

                $this->adminmodel->updateBsmrIntro($id,$title, $body);
                $this->load->helper('url');
                redirect('http://localhost/bsmrmt/adminPanel/bsmr_intro_show', 'refresh');

            }
        }
    }

//--------------------Bsmrmt Show-------------------
    public function bsmr_intro_show()
    {
        $data['intro']=$this->adminmodel->addBsmrIntroShow();
        $this->load->view('view_bsmr_intro_show',$data);
    }

    public function bsmr_intro_delete($id)
    {
        $data['intro']=$this->adminmodel->addBsmrIntroDelete($id);
        $this->load->helper('url');
        redirect('http://localhost/bsmrmt/adminPanel/bsmr_intro_show', 'refresh');
    }

    //--------------------trust intro Show-------------------
    public function trust_intro_show()
    {
        $data['intro']=$this->adminmodel->addTrustIntroShow();
        $this->load->view('view_trust_intro_show',$data);
    }

    //--------------------trust Edit-------------------
    public function trust_intro_edit($id)
    {


        $this->form_validation->set_rules("title", "title", "required");
        $this->form_validation->set_rules("body", "body", "required");


        if ($this->form_validation->run() == false) {

            $data['editPage']=$this->adminmodel->getTrustIntro($id);
            $this->load->view('view_trust_intro_edit',$data);
        } else {

            if ($this->input->post('submit')) {
                $title = $this->input->post("title");
                $body = $this->input->post("body");

                $this->adminmodel->updatetrustIntro($id,$title, $body);
                $this->load->helper('url');
                redirect('http://localhost/bsmrmt/adminPanel/trust_intro_show', 'refresh');

            }
        }
    }

    public function trust_intro_delete($id)
    {
        $data['intro']=$this->adminmodel->addTrustIntroDelete($id);
        $this->load->helper('url');
        redirect('http://localhost/bsmrmt/adminPanel/trust_intro_show', 'refresh');
    }

    //--------------------trust aim Show-------------------
    public function trust_aim_show()
    {
        $data['intro']=$this->adminmodel->addTrustAimShow();
        $this->load->view('view_trust_aim_show',$data);
    }

    public function trust_aim_delete($id)
    {
        $data['intro']=$this->adminmodel->addTrustAimDelete($id);
        $this->load->helper('url');
        redirect('http://localhost/bsmrmt/adminPanel/trust_aim_show', 'refresh');
    }



    //--------------------trust work Show-------------------
    public function trust_work_show()
    {
        $data['intro']=$this->adminmodel->addTrustWorkShow();
        $this->load->view('view_trust_work_show',$data);
    }

    public function trust_work_delete($id)
    {
        $data['intro']=$this->adminmodel->addTrustWorkDelete($id);
        $this->load->helper('url');
        redirect('http://localhost/bsmrmt/adminPanel/trust_work_show', 'refresh');
    }


    //--------------------Photo Show-------------------
    public function photo_show()
    {
        $data['intro']=$this->adminmodel->addPhotoShow();
        $this->load->view('view_photo_show',$data);
    }

    public function photo_delete($id)
    {
        $data['intro']=$this->adminmodel->addPhotoDelete($id);
        $this->load->helper('url');
        redirect('http://localhost/bsmrmt/adminPanel/photo_show', 'refresh');
    }

    //--------------------Video Show-------------------
    public function video_show()
    {
        $data['intro']=$this->adminmodel->addVideoShow();
        $this->load->view('view_video_show',$data);
    }

    public function video_delete($id)
    {
        $data['intro']=$this->adminmodel->addVideoDelete($id);
        $this->load->helper('url');
        redirect('http://localhost/bsmrmt/adminPanel/video_show', 'refresh');
    }

    //--------------------Bani Show-------------------
    public function bani_show()
    {
        $data['intro']=$this->adminmodel->addBaniShow();
        $this->load->view('view_bani_show',$data);
    }

    public function bani_delete($id)
    {
        $data['intro']=$this->adminmodel->addBaniDelete($id);
        $this->load->helper('url');
        redirect('http://localhost/bsmrmt/adminPanel/bani_show', 'refresh');
    }


// -------------------------Sign Out---------------------------

    public function logout()
    {
        $this->session->unset_userdata('admin');
        $this->load->helper('url');
        redirect('http://localhost/bsmrmt', 'refresh');
    }
}