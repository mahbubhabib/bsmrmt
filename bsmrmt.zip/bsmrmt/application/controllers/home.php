<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: MahbubHabib
 * Date: 14-01-18
 * Time: 13.38
 */
class Home extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('form', 'url', 'file');
        $this->load->library('form_validation');
        $this->load->model('homemodel');
    }
    public function index()
    {
        $data['pic']=$this->homemodel->addPhotoShow();
        $data['aim']=$this->homemodel->addTrustAimShow();
        $data['work']=$this->homemodel->addTrustWorkShow();
        $this->load->view('view_home',$data);
    }

    public function bsmr_intro()
    {
        $data['bsmr']=$this->homemodel->addBsmrmtIntroShow();
        $this->load->view('view_bsmrmt_intro',$data);
    }

    public function trust_intro()
    {
        $data['bsmr']=$this->homemodel->addHomeTrustIntroShow();
        $this->load->view('view_home_trust_intro',$data);
    }

    public function trust_aim()
    {
        $data['bsmr']=$this->homemodel->addTrustAimShow();
        $this->load->view('view_home_trust_aim',$data);
    }

    public function trust_work()
    {
        $data['bsmr']=$this->homemodel->addTrustWorkShow();
        $this->load->view('view_home_trust_work',$data);
    }
//-------------------------------------------------------------------------------
    public function trust_work_details($id)
    {
        $data['bsmr']=$this->homemodel->trustWorkDetails($id);
        $this->load->view('view_home_trust_work_details',$data);
    }

    public function photo()
    {
        $data['bsmr']=$this->homemodel->addPhotoShow();
        $this->load->view('view_home_photo',$data);
    }

    public function video()
    {
        $data['bsmr']=$this->homemodel->addVideoShow();
        $this->load->view('view_home_video',$data);
    }

    public function bani()
    {
        $data['bsmr']=$this->homemodel->addbaniShow();
        $this->load->view('view_home_bani',$data);
    }

    public function update()
    {
        $this->load->view('view_home_update');
    }

    public function contact()
    {
        $this->load->view('view_contact');
    }


}